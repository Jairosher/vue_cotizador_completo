<template>
  <div>
    <h2>Bienvenido al panel de administración</h2>
    <p>Desde aquí podrás ver y modificar los archivos JSON.</p>
  </div>
</template>

<script>
export default {
  name: 'Dashboard'
}
</script>